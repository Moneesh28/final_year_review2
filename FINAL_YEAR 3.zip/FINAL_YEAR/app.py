from flask import Flask, request, render_template, jsonify, redirect, url_for
import fitz  # PyMuPDF
import re  # Regular expressions

app = Flask(__name__)

# Function to extract text from a single PDF file
def extract_text_from_pdf(pdf_path):
    text = ""
    with fitz.open(pdf_path) as pdf:
        for page_num in range(pdf.page_count):
            page = pdf[page_num]
            text += page.get_text()
    return text

# Function to summarize key health metrics from the extracted text
def summarize_report(text):
    summary = {}
    important_terms = {
        "Hemoglobin": r"(?i)\bhemoglobin\s*\(?Hb\)?\s*([0-9]*\.?[0-9]+)",
        "WBC": r"(?i)\bwbc\s*count\s*([0-9]*\.?[0-9]+)",
        "RBC": r"(?i)\brbc\s*count\s*([0-9]*\.?[0-9]+)",
        "Platelet": r"(?i)\bplatelet\s*count\s*([0-9]*\.?[0-9]+)"
    }
    for term, pattern in important_terms.items():
        match = re.search(pattern, text)
        if match:
            value = match.group(1).strip()
            summary[term] = value
    return summary

@app.route("/")
def home():
    return render_template("home.html")

@app.route("/summarizer")
def summarizer():
    return render_template("ii.html")

@app.route("/upload", methods=["POST"])
def upload():
    if "file" not in request.files:
        return jsonify({"error": "No file part"}), 400
    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No selected file"}), 400
    if file:
        file_path = "uploaded_report.pdf"
        file.save(file_path)
        text = extract_text_from_pdf(file_path)
        print("Extracted Text:\n", text)
        summary = summarize_report(text)
        if not summary:
            return jsonify({"error": "No summary available"}), 404
        return jsonify(summary)

if __name__ == "__main__":
    app.run(debug=True, port=5002)
